//
//  ViewController.m
//  MMPhoto
//
//  Created by 李沫 on 2019/3/1.
//  Copyright © 2019 MOMO. All rights reserved.
//

#import "ViewController.h"
#import "MMPhotoView/MMPhotoViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:@"photo"] forState:UIControlStateNormal];
    btn.frame = CGRectMake(100, 100, 100, 50);
    btn.imageView.contentMode = UIViewContentModeScaleAspectFill;
    btn.clipsToBounds = YES;
    btn.tag = 1000;
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    UIButton *secondBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [secondBtn setImage:[UIImage imageNamed:@"photo"] forState:UIControlStateNormal];
    secondBtn.frame = CGRectMake(100, 300, 100, 50);
    secondBtn.imageView.contentMode = UIViewContentModeScaleAspectFill;
    secondBtn.clipsToBounds = YES;
    secondBtn.tag = 1001;
    [secondBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:secondBtn];
    
}
-(void)btnClick:(UIButton *)btn{
    MMPhotoViewController *vc = [[MMPhotoViewController alloc] init];
    vc.urlArray = @[@"https://img-my.csdn.net/uploads/201407/26/1406383299_1976.jpg",
                    @"https://img-my.csdn.net/uploads/201407/26/1406383291_6518.jpg",
                    @"https://img-my.csdn.net/uploads/201407/26/1406383291_8239.jpg"
                   ];
    vc.imgIndex = 1;
    if (btn.tag == 1000) {
        vc.rect = btn.frame;//传一个frame,消失时会回归原位，不传会在手指离开的位置消失
    }
    
    [self.view addSubview:vc.view];
    [self addChildViewController:vc];
}

@end
