//
//  AutoDismissAlert.h
//  ZZGHapp
//
//  Created by 赵 志岩 on 2017/3/22.
//  Copyright © 2017年 Ingcare. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface AutoDismissAlert : NSObject
+ (void)autoDismissAlert2With:(NSString *)string; //字数较长的时候
@end
